###EIGENVALORES
#Matriz de 2 × 2 de 4 números reales al azar 
matriz <- matrix (rnorm(4), nrow=2, ncol=2) #uso rnorm para generar numeros aleatorios normales, indico que tome 4
print (matriz)

#Traza de la matriz
diag_mat <- diag (matriz) #con diag, obtengo los números en la diagonal 
sum (diag_mat) #sumo los elementos que tengo en el objeto, que son los elementos de la diagonal
traza <- sum (diag_mat) 
print(traza)

#Determinante de la matriz
print (det (matriz)) #uso la función det para calcularla 
det_mat <- det(matriz) #guardo la determinante en un objeto 

#Calcula los eigenvalores de la matriz
eigen (matriz) #utilizo la función eigen que es parte del paquete básicode R 
eig_mat <- eigen (matriz)
print (eig_mat)

#Cálculo para determinar el tipo de punto de equilibrio
traza^2 - (4*det_mat) -> ep_type

##Determina a partir de la traza y determinante, el tipo y clase de estabilidad que tiene
if (det_mat < 0 ) {
  print ("Tipo: punto silla")
} else if (traza < 0 & ep_type > 0) {
  print ("Equilibrio: estable     Tipo: atractor directo")
} else if (traza < 0 & ep_type < 0) {
  print ("Equilibrio: estable     Tipo: atractor espiral") 
} else if (traza > 0 & ep_type > 0 ) {
  print ("Equilibrio: inestable   Tipo: repulsor directo") 
} else if (traza > 0 & ep_type < 0 ) {
  print ("Equilibrio: inestable   Tipo: repulsor espiral") 
}

##A partir de la parte REAL de los eigenvalores, determina el tipo y clase de estabilidad que tienen.
#Para calcular el punto de equilibrio directamente, se puede utilizar Re ()
#Re () es una función que permite seleccionar  los valores reales de un número definido como complejo 

#Cuando:
#ambos eigenvalores son negativos, tenemos un punto de equilibrio estable
#alguno de los eigenvalores es positivo, se trata de un punto silla
#ambos eigenvalores son positivos, tenemos un punto inestable

if  ( all(Re (eig_mat$values) < 0) ) {
  print("Equilibrio: estable ") #ambos eigenvalores reales son negativos, punto estable 
} else if ( any (Re (eig_mat$values) > 0) ) {
  print ("Tipo: punto silla") #alguno de los eigenvalores es positivo, punto inestable 
} else if (all (Re (eig_mat$values) > 0) ) {
  print ("Equilibrio: inestable") #ambos eigenvalores  positivos, punto inestable
} 


##Genera 100 matrices al azar, demuestra que aprox. el 50% de las veces es un punto silla.
generate_m <- matrix (rnorm(4), nrow = 2, ncol = 2) #quiero hacer esto 100 veces, uso:
conj_mat <- lapply (1:100, function (x) generate_m) #esto hace que me de 100 matrices iguales cuando imprimo
print (conj_mat) 
#la función lapply permite que, a cada uno de los elementos que se están indicando como 1:100
# se le aplique generate_m: matrix (rnorm(4), nrow = 2, ncol = 2)
#En otras palabras, 1:100 indica que genere lo que se le está pidiendo después de la coma en generate_m 100 veces
#function (x) es para indicar en lapply qué se va a aplicar a los elementos de la lista 
#para que no me de 100 matrices iguales lo cambio a:
conj_mat <- lapply (1:100, function (x) matrix (rnorm(4), nrow = 2, ncol = 2)) 

print (conj_mat [[2]]) #imprimo algunas matrices de las 100 generadas para checar que se corrió bien 
print (conj_mat [[57]]) #y que no sean las mismas 
print (conj_mat [[89]])

#Para calcular si el 50% son puntos sillas, se debe calcular primero la determinante de cada matriz
conj_deter <- lapply (conj_mat, function (x) det(x)) #para que calcule la det de cada matriz en conj_mat
print(conj_deter)

silla <- conj_deter < 0
print (silla) #muestra el resultado en valores booleanos 
#cuento las veces que sale TRUE en silla
c_silla <- sum (silla) #Hace la suma de los TRUE
print (c_silla)
#Porcentaje se calcula: (total de las determinantes < 0 (silla) / todas las determinantes) * 100
perc_silla <- (c_silla / length(conj_deter)) * 100
cat("Porcentaje de puntos silla en 100 matrices:", perc_silla, "%\n")
#Porcentaje del 51% d epuntos silla en 100 matrices aleatoreamente generadas 



