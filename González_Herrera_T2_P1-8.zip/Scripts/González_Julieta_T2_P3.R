###CALIFICACIONES
#A partir de un vector de calificaciones de exámenes parciales (3) y 
#de un vector de calificaciones de tareas y exámenes quincenales (10):
#Determine si exentaría o no el curso
#Asume que en el resto de los criterios tienen el 100%

exam_cal <- sample (1:10, 3, replace = TRUE) #añado replace para que se puedan repetir los números 
print (exam_cal)
quincenal_cal <- sample (1:10, 10, replace =TRUE)
print (quincenal)

#Se multiplica cada uno de los porcentajes del concepto por 100 para obtener un decimal 
exam <- 0.5 * mean (exam_cal) #multiplico por el promedio de las calificaciones
quincenal <- 0.3 * mean (quincenal_cal)
expo_proy <- 0.1*10
expo_art <- 0.05*10
particip <- 0.05*10
extra <- 0.05*10 #asumiendo que este vale el 5%

cal_f <- exam + quincenal + expo_proy + expo_art + particip + extra 

if (cal_f >= 6) {
  print ("Exenta")
} else { 
  print ("No exenta")
}
