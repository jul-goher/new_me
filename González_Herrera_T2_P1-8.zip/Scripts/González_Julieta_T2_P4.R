###ESTRUCTURAS DE SELECCIÓN 

#Programa que muestre edad, signo del zodiaco y estación del año de nacimiento
as.numeric (readline ("Día en el que naciste (ej. 1) ") ) -> b_day
as.numeric (readline ("Ingresa el mes en el que naciste por su número (ej. Si eres de febrero, pon un 2) " ) ) -> b_mon
as.numeric (readline ("Año en el que naciste, ej. 2001 ")) -> b_year

##EDAD##
print (paste ("Tienes", 2024-b_year, "años"))

##ZODIACO##
#Gemini (Twins): May 21–June 21
#Cancer (Crab): June 22–July 22
#Leo (Lion): July 23–August 22
#Virgo (Virgin): August 23–September 22
#Libra (Balance): September 23–October 23
#Scorpius (Scorpion): October 24–November 21
#Sagittarius (Archer): November 22–December 21
#Capricornus (Goat): December 22–January 19
#Aquarius (Water Bearer): January 20–February 18
#Pisces (Fish): February 19–March 20
#Aries (Ram): March 21–April 19
#Taurus (Bull): April 20–May 20

if ((b_mon == 5 & b_day >= 21 & b_day <= 31) | (b_mon == 6 & b_day >= 1 & b_day <= 21)) {
  print ("Géminis")
} else if ((b_mon == 6 & b_day >= 22 & b_day <= 30 ) | (b_mon == 7 & b_day >= 1 & b_day <= 22)) {
  print ("Cancer")
} else if ((b_mon == 7 & b_day >= 23 & b_day <= 31) | (b_mon == 8 & b_day >= 1 & b_day <= 22)) {
  print ("Leo")
} else if ((b_mon == 8 & b_day >= 23 & b_day <= 31) | (b_mon == 9 & b_day >= 1 & b_day <= 22)) {
  print ("Virgo") 
} else if ((b_mon == 9 & b_day >= 23 & b_day <= 30) | (b_mon == 10 & b_day >= 1 & b_day <= 23)) {
  print ("Libra") 
} else if ((b_mon == 10 & b_day >= 24 & b_day <= 31) | (b_mon == 11 & b_day >= 1 & b_day <= 21)) {
  print ("Escorpio") 
} else if ((b_mon == 11 & b_day >= 22 & b_day <= 30) | (b_mon == 12 & b_day >= 1 & b_day <= 21)) {
  print ("Sagitario") 
} else if ((b_mon == 12 & b_day >= 22 & b_day <= 31) | (b_mon == 1 & b_day >= 1 & b_day <= 19)) {
  print ("Capricornio") 
} else if ((b_mon == 1 & b_day >= 20 & b_day <= 31) | (b_mon == 2 & b_day >= 1 & b_day <= 18)) {
  print ("Aquario") 
} else if ((b_mon == 2 & b_day >= 19 & b_day <= 29) | (b_mon == 3 & b_day >= 1 & b_day <= 20)) {
  print ("Piscis") 
} else if ((b_mon == 3 & b_day >= 21 & b_day <= 31) | (b_mon == 4 & b_day >= 1 & b_day <= 19)) {
  print ("Aries") 
} else if ((b_mon == 4 & b_day >= 20 & b_day <= 31) | (b_mon == 5 & b_day >= 1 & b_day <= 18)) {
  print ("Tauro") 
} 

##ESTACIONES##
#hago vectores para los meses que por completo pertenecen a una estación y no a dos
#Verano: inicia el 21 de junio y finaliza el 23 de septiembre.
oblig_ver <- 7:8 #no incluyo a junio (6) ni a septiembre (9) porque no todos sus días son de verano
#Otoño: inicia el 23 de septiembre y finaliza el 21 de diciembre.
oblig_oto <- 10:11
#Invierno: inicia el 21 de diciembre y finaliza el 20 de marzo.
oblig_inv <- 1:2
#Primavera: inicia el 20 de marzo y finaliza el 21 de junio.  
oblig_pri <- 4:5

if ((b_mon == 6 & b_day >= 21) | any (b_mon == oblig_ver) | (b_mon == 9 & b_day <= 22)) {
  print ("Summer baby")
} else if ((b_mon == 9 & b_day >= 23) | any (b_mon == oblig_oto) | (b_mon == 12 & b_day <= 20)) { 
  print ("Autumn baby") 
} else if ((b_mon == 12 & b_day >= 21) | any (b_mon == oblig_inv) | (b_mon == 3 & b_day <= 19)) { 
    print ("Winter baby") 
} else if ((b_mon == 3 & b_day >= 20) | any (b_mon == oblig_pri) | (b_mon == 6 & b_day <= 20)) { 
    print ("Spring baby") 
}




