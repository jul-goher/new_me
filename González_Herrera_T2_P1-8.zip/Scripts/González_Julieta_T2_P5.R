###ALINEAMIENTO MÚLTIPLE
#Instalar paquetes
if (!requireNamespace("BiocManager"))
  install.packages("BiocManager")
BiocManager::install(version = "3.19")

BiocManager::install("Biostrings")
library (Biostrings) #cargar librería

#Leer el archivo fasta como un StringSet de ADN
fasta1 <- readDNAStringSet ("/Users/julie/OneDrive/Escritorio/R/Bioinformática/Tarea2_JGH/Datos/FASTA.fa")
fasta1 #ya que esta ruta es específica del lugar de almacenaje de mi equipo, no funcionará en otro lado 

####Número de veces que aparece la secuencia GATTACA
matchPattern("GATTACA", fasta1 [[1]]) #no cuenta la secuencia, sólo encuentra el patrón en mi primer secuencia
matchPattern("GATTACA", fasta1 [[2]]) #lo mismo, pero en la segunda secuencua
times_seq <- vcountPattern ("GATTACA", fasta1) #uso vcountPattern porque tengo múltiples secuencias, y este sí muestra el conteo 
print (times_seq) #cuenta el patrón en las 12 secuencias del archivo FASTA

####La secuencia traducida
traduc_AA <- translate (fasta1) #muestra la secuencia de ADN en secuencia de aminoácidos
print (traduc_AA)
#No permite traducir la secuencia porque me marca el sig. error: 
#Error in 'x[[3]]': not a base at pos 28 , me indica que hay una letra que no es un nucleotido en
#la posición 28 (pos 28) de la 3er secuencia [[3]], que, checando la secuencia, es una R
IUPAC_CODE_MAP 
#según el mapa de IUPAC, la R significa una "AG"

#Opto por reemplazar todas las bases ambiguas por N, que, según el código IUPAC, pueden representar cualquier base 
new_fasta <- ( sapply (fasta1, function (seq) { #utilizo sapply, para que lo aplique a cada sec. del fasta
  gsub ("[^ATCG]", "N", as.character (seq))  #gsub para que indicar que no reemplace el conjunto de caracteres en el corchete
})) #reemplaza todo menos ATCG, por el uso del símbolo  ^
traduc_new <- translate (new_fasta) #creo que no corre porque sapply es para listas ? y porque no puede leer N ?

#Decidí eliminar manualmente los nucleótidos de las secuencias 3 (que tiene una R) y 12 (que tiene una S)
#y repetir el procedimiento  

###3er intento###
fasta2 <- readDNAStringSet ("/Users/julie/OneDrive/Escritorio/R/Bioinformática/Tarea2_JGH/Datos/modif_FASTA.fa")
#mi nuevo archivo sin los nucleotidos ambiguos se llama modif_FASTA.fa
#Cuento secuencias de nuevo
times_seq2 <- vcountPattern ("GATTACA", fasta2)
print (times_seq2)
#Traducir el nuevo fasta a aminoácidos 
fasta2_traduc <- translate (fasta2)
print (fasta2_traduc) #como algunas secuencias no son múltiplos de 3, ignora 2 bases al final

###Alineamiento múltiple por al menos dos algoritmos distintos para la secuencia de AA
BiocManager::install("msa")
library (msa)

align1 <- msa (fasta2_traduc, method = "ClustalW")
align2 <- msa (fasta2_traduc, method = "Muscle")

#Antes de la matriz de distancias de las secuencias
#como enla funcion as.numeric, pero sustituyo el numeric por AAStringSet
align1_string <- as(align1, "AAStringSet")
print (align1_string)
align2_string <- as(align2, "AAStringSet")
print (align2_string)

#Esto es para utilizarlas en la matriz de distancia
install.packages("ape")
library (ape) #cargar el paquete que me permita hacer el árbol filogenético 
install.packages("stringdist") #paquete para la matriz de distancia 
library(stringdist)

###Crear matrices de distancia 
dist_m1 <- dist.aa (align1_string) #dist.aa porque estpy trabajando con aminoácidos 
print (dist_m1) 

dist_m2 <- dist.aa (align2_string)
print (dist_m2) 

###Árbol filogenético a partir de uno de los alineamientos
phyl_tree <- nj (dist_m1) #hacer el parbol mediante el método neighbor-joining en paquete ape
plot (phyl_tree) #para visualizar el árbol


