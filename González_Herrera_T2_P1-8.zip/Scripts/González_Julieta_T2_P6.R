###JURASSIC PARK 
#Instalar y  paquetes
if (!requireNamespace("BiocManager"))
  install.packages("BiocManager")
BiocManager::install(version = "3.19")

BiocManager::install("Biostrings")
library (Biostrings)

#Lee el archivo en R y calcula el porcentaje de GC y de C seguido de G
fasta_dino <- readDNAStringSet ("/Users/julie/OneDrive/Escritorio/R/Bioinformática/Tarea2_JGH/Datos/DinoJurassic.fna")
#Porcentaje de G y de C
d_gc <- letterFrequency (fasta_dino, c("G", "C")) / (width (fasta_dino)) * 100 #función width porque length sólo cuenta a la única secuencia 
print (d_gc)

#Porcentaje CG (juntas)
d_cg <- oligonucleotideFrequency (fasta_dino, "CG")/ (width (fasta_dino))*100
print (d_cg)

d1 <- letterFrequency (fasta_dino, "CG") / (width (fasta_dino)) 
paste ("Porcentage de CG:", d1, "%") #

alphabetFrequency (fasta_dino) [c("C", "G")]
d2<- alphabetFrequency(fasta_dino)["C"] + alphabetFrequency(fasta_dino)["G"]
paste ("Porcentage de CG:", d2*100, "%") 

###Blastea la secuencia
#Resultado del BLAST fue descargado como un csv
library (readr)
dino_BLAST <- read.csv ("Datos/dino_BLAST.csv")
View(dino_BLAST)

###¿Cuáes serían los organismos más cercanos? ¿Tiene sentido que la secuencia sea de dinosaurios? ####
#Los organismos más cercanos en sí no incluyen organismo, sino vectores de clonación y de expresión 
#Quizás sí tendría sentido que la secuencia fuese de dinosaurio si consideramos que estos dinosaurios son 
#resultado de múltiples clonaciones donde se ha buscado rescatar su genoma. 
#No obstante, dejaríamos de lado que realmente no existe una secuencia única de estos organismos 
#o que ni siquiera se indique una secuencia quelos realacione a otros organismos con 
#parentezco cercano, como aves y reptiles.

#Elabora una gráfica de e-values y los organismos más cercanos.
hist_dino <- hist (dino_BLAST$E.value, col="plum4")
print <- hist_dino
#no hay diferencia en la gráfica debido a que todos los e-values son iguales 

###Elabora un árbol filogenético con los 10 organismos más cercanos
BiocManager::install("msa")
library (msa)

dino_fa <-  readDNAStringSet ("/Users/julie/OneDrive/Escritorio/R/Bioinformática/Tarea2_JGH/Datos/seq_dino_BLAST.fa")
align_dino <- msa (dino_fa) #multiple sequence alignment 

align_dino_ss <- as(align_dino, "AAStringSet") #para que lo guarde como un AAStringSet

##Matriz de distancias
install.packages ("stringdist") #para crear la matriz de distancia 
library (stringdist)

dist_m_dino <- dist.aa (align_dino_ss)
print (dist_m_dino)

#Árbol filogenético 
install.packages("ape")
library (ape) #para hacer el árbol por neighbor-joining con la matriz de distancia 
dino_tree <- nj (dist_m_dino)
print (dino_tree) #Me indica que el árbol no tiene raíz
#Quizás la adición de un grupo externo lo arregle 

