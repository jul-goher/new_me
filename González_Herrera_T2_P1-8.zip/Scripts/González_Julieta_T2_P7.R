###PRINCIPIO DEL TÍO BEN###
#A partir del “poder” de diez personajes dado como datos de entrada
#Genera un mensaje para cada uno de ellos que indique el mensaje:
#“Con un gran poder conlleva una gran responsabilidad” si es que su “poder” es mayor que un valor umbral.
#Si su personaje es spider-man, les debe arrojar el mensaje del tío Ben.

readline("Del 1:100, elige un valor del poder para tu personaje ") -> pow_char 

characters <- c("Hawkgirl", "Deathstroke", "Juggernaut", "Poison Ivy", "Harley Quinn", "Flash", "Batman", "Wonderwoman", "Spiderman", "Superman")
powers <- c (10, 20, 30, 40, 50, 60, 70, 80, 90, 100) #umbral del poder 
names (powers) <- characters #para asignar los umbrales a su caracter respectivo 
print (powers)

if (pow_char > powers [[8]] & pow_char <= powers [[9]]) {
  print ("Con un gran poder conlleva una gran responsabilidad")
} else if (pow_char > powers [[6]] & pow_char <= powers [[7]] ) {
  print ( "Eres Batman" )
} else if (pow_char > powers [[5]] & pow_char <= powers [[6]] ) {
  print ( "Eres Flash" )
} else if (pow_char > powers [[7]] & pow_char <= powers [[8]] ) {
  print ("Eres Wonderwoman" )
} else if (pow_char > powers [[4]] & pow_char <= powers [[5]] ) {
  print ("Eres Harley Quinn" )
} else if (pow_char > powers [[3]] & pow_char <= powers [[4]] ) {
  print ("Eres Poison Ivy" )
} else if (pow_char > powers [[1]] & pow_char <= powers [[2]] ) {
  print ("Eres Deathstroke" )
} else if (pow_char > powers [[2]] & pow_char <= powers [[3]] ) {
  print ("Eres Juggernaut" )
} else if (pow_char >= 1 & pow_char <= powers [[1]] ) {
  print ("Eres Hawkgirl" )
} else if (pow_char > powers [[9]] & pow_char <= powers [[10]] ) {
  print ("Eres Superman" )
}

