####INDICE DE MASA CORPORAL####
#El programa debe pedir al usuario, su nombre, su peso (en kg) y altura (en metros), calcular
#su IMC, y luego imprimir en pantalla tanto el IMC como la categor´ıa correspondiente
readline ("Escribe tu nombre como: Apellido Nombre ") -> p_name
as.numeric (readline ("Ingresa tu peso en kg. *Sólo el número. ")) -> p_weight
as.numeric (readline ("Ingresa tu altura en metros. *Sólo el número, en decimal. ")) -> p_height

#Fórmula ---------------------
IMC <- p_weight / (p_height^2)

#Condiciones, definir los rangos 
#Bajo peso: IMC menor a 18.5
#Normal: IMC entre 18.5 y 24.9
#Sobrepeso: IMC entre 25.0 y 29.9
#Obesidad: IMC igual o mayor a 30.0

if (IMC < 18.5 ) {
  paste ("Paciente de nombre:", p_name, ", con un IMC de", IMC, "tiene bajo peso" )
} else if (IMC >= 18.5 & IMC < 24.9) {
  paste ("Paciente de nombre:", p_name, ", con un IMC de", IMC, "tiene peso normal" )
} else if (IMC >= 25 & IMC < 29.9) {
  paste ("Paciente de nombre:", p_name, ", con un IMC de", IMC, "tiene sobrepeso" )
} else if (IMC >= 30) {
  paste ("Paciente de nombre:", p_name, ", con un IMC de", IMC, "tiene obesidad" )
}

